PRAMBH - the first survey
=======================

This station is a set of field instruments and the surveyor's notes.
Nothing here talks to a network; nothing needs installing.

  ./stage0_milestone/milestone      start here
  ./field-notes/                    the first surveyor's notes
  ./archive/                        the survey's paper record
  ./plates/                         the plates the depot shipped

Run the instruments from this folder; they keep their working record
here.  Read every sheet before you decide it is quiet.
